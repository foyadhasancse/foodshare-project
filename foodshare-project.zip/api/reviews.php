<?php

require_once '../config/constants.php';
require_once '../config/paths.php';
require_once '../config/settings.php';
require_once 'config.php';
require_once '../middleware/auth.php';
require_once '../utils/helpers.php';

header('Content-Type: application/json');

$method = getMethod();
$action = $_GET['action'] ?? '';

verifyToken();

switch ($action) {
    case 'create':
        createReview();
        break;
    case 'get':
        getReview();
        break;
    case 'list':
        listReviews();
        break;
    case 'user-reviews':
        getUserReviews();
        break;
    case 'update':
        updateReview();
        break;
    case 'delete':
        deleteReview();
        break;
    default:
        sendError('Invalid action', 400);
}

function createReview() {
    global $conn;
    validateMethod(['POST']);

    $data = getRequestData();
    $reviewerId = $_SESSION['user_id'];

    $required = ['request_id', 'rating'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            sendError("$field is required", 400);
        }
    }

    if ($data['rating'] < 1 || $data['rating'] > 5) {
        sendError('Rating must be between 1 and 5', 400);
    }

    $reqStmt = $conn->prepare(
        "SELECT r.donation_id, r.recipient_id, r.status, do.donor_id
         FROM requests r
         JOIN donations do ON r.donation_id = do.id
         WHERE r.id = ?"
    );
    $reqStmt->bind_param("i", $data['request_id']);
    $reqStmt->execute();
    $reqResult = $reqStmt->get_result();

    if ($reqResult->num_rows === 0) {
        sendError('Request not found', 404);
    }

    $request = $reqResult->fetch_assoc();
    $reqStmt->close();

    if ($request['status'] !== REQ_COMPLETED) {
        sendError('You can only leave a review after the donation has been received', 400);
    }

    if ((int)$reviewerId === (int)$request['donor_id']) {
        $revieweeId = $request['recipient_id'];
    } elseif ((int)$reviewerId === (int)$request['recipient_id']) {
        $revieweeId = $request['donor_id'];
    } else {
        sendError('You are not part of this donation', 403);
    }

    $dupStmt = $conn->prepare("SELECT id FROM reviews WHERE reviewer_id = ? AND request_id = ?");
    $dupStmt->bind_param("ii", $reviewerId, $data['request_id']);
    $dupStmt->execute();
    if ($dupStmt->get_result()->num_rows > 0) {
        sendError('You already reviewed this donation', 400);
    }
    $dupStmt->close();

    $query = "INSERT INTO reviews (reviewer_id, reviewee_id, donation_id, request_id, rating, comment, created_at)
              VALUES (?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $conn->prepare($query);
    $donationId = $request['donation_id'];
    $requestId = $data['request_id'];

    $stmt->bind_param(
        "iiiiis",
        $reviewerId,
        $revieweeId,
        $donationId,
        $requestId,
        $data['rating'],
        $data['comment'] ?? null
    );

    if ($stmt->execute()) {
        $reviewId = $conn->insert_id;

        updateUserRating($revieweeId);

        createNotification(
            $revieweeId,
            'New review received',
            'You received a new ' . $data['rating'] . '-star review.',
            'review_received',
            $reviewId,
            'review'
        );

        logActivity($reviewerId, 'review_created', 'Created review for user #' . $revieweeId);
        sendSuccess('Review created successfully', ['review_id' => $reviewId]);
    } else {
        sendError('Failed to create review', 500);
    }

    $stmt->close();
}

function getReview() {
    global $conn;
    validateMethod(['GET']);

    $id = $_GET['id'] ?? null;
    if (!$id) {
        sendError('Review ID required', 400);
    }

    $query = "SELECT r.*, u.full_name as reviewer_name, u.profile_picture
              FROM reviews r
              JOIN users u ON r.reviewer_id = u.id
              WHERE r.id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Review not found', 404);
    }

    $review = $result->fetch_assoc();
    $stmt->close();

    sendSuccess('Review retrieved', $review);
}

function listReviews() {
    global $conn;
    validateMethod(['GET']);

    $userId = $_GET['user_id'] ?? null;
    if (!$userId) {
        sendError('User ID required', 400);
    }

    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $countQuery = "SELECT COUNT(*) as total FROM reviews WHERE reviewee_id = ?";
    $stmt = $conn->prepare($countQuery);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $total = $stmt->get_result()->fetch_assoc()['total'];
    $stmt->close();

    $query = "SELECT r.*, u.full_name as reviewer_name, u.profile_picture
              FROM reviews r
              JOIN users u ON r.reviewer_id = u.id
              WHERE r.reviewee_id = ?
              ORDER BY r.created_at DESC
              LIMIT ? OFFSET ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("iii", $userId, $perPage, $offset);
    $stmt->execute();
    $result = $stmt->get_result();

    $reviews = [];
    while ($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }
    $stmt->close();

    $pagination = [
        'current_page' => $page,
        'per_page' => $perPage,
        'total' => $total,
        'total_pages' => ceil($total / $perPage)
    ];

    sendSuccess('Reviews retrieved', $reviews, $pagination);
}

function getUserReviews() {
    global $conn;
    validateMethod(['GET']);

    $userId = $_SESSION['user_id'];
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $query = "SELECT r.*, u.full_name as reviewee_name
              FROM reviews r
              JOIN users u ON r.reviewee_id = u.id
              WHERE r.reviewer_id = ?
              ORDER BY r.created_at DESC
              LIMIT ? OFFSET ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("iii", $userId, $perPage, $offset);
    $stmt->execute();
    $result = $stmt->get_result();

    $reviews = [];
    while ($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }
    $stmt->close();

    sendSuccess('Your reviews retrieved', $reviews);
}

function updateReview() {
    global $conn;
    validateMethod(['PUT', 'POST']);

    $data = getRequestData();
    $userId = $_SESSION['user_id'];
    $reviewId = $data['id'] ?? null;

    if (!$reviewId) {
        sendError('Review ID required', 400);
    }

    $stmt = $conn->prepare("SELECT reviewer_id FROM reviews WHERE id = ?");
    $stmt->bind_param("i", $reviewId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Review not found', 404);
    }

    $review = $result->fetch_assoc();
    $stmt->close();

    if ((int)$review['reviewer_id'] !== (int)$userId) {
        sendError('Unauthorized', 403);
    }

    if (isset($data['rating']) && ($data['rating'] < 1 || $data['rating'] > 5)) {
        sendError('Rating must be between 1 and 5', 400);
    }

    $query = "UPDATE reviews SET rating = ?, comment = ?, updated_at = NOW() WHERE id = ?";

    $stmt = $conn->prepare($query);
    $rating = $data['rating'] ?? 5;
    $comment = $data['comment'] ?? null;
    $stmt->bind_param("isi", $rating, $comment, $reviewId);

    if ($stmt->execute()) {
        sendSuccess('Review updated successfully');
    } else {
        sendError('Failed to update review', 500);
    }

    $stmt->close();
}

function deleteReview() {
    global $conn;
    validateMethod(['DELETE', 'POST']);

    $data = getRequestData();
    $userId = $_SESSION['user_id'];
    $reviewId = $data['id'] ?? null;

    if (!$reviewId) {
        sendError('Review ID required', 400);
    }

    $stmt = $conn->prepare("SELECT reviewer_id, reviewee_id FROM reviews WHERE id = ?");
    $stmt->bind_param("i", $reviewId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Review not found', 404);
    }

    $review = $result->fetch_assoc();
    $stmt->close();

    if ((int)$review['reviewer_id'] !== (int)$userId) {
        sendError('Unauthorized', 403);
    }

    $stmt = $conn->prepare("DELETE FROM reviews WHERE id = ?");
    $stmt->bind_param("i", $reviewId);

    if ($stmt->execute()) {

        updateUserRating($review['reviewee_id']);

        sendSuccess('Review deleted successfully');
    } else {
        sendError('Failed to delete review', 500);
    }

    $stmt->close();
}

function updateUserRating($userId) {
    global $conn;

    $query = "SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM reviews WHERE reviewee_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $avgRating = $result['avg_rating'] ?? 0;

    $updateStmt = $conn->prepare("UPDATE users SET rating = ? WHERE id = ?");
    $updateStmt->bind_param("di", $avgRating, $userId);
    $updateStmt->execute();
    $updateStmt->close();
}

?>
