<?php

require_once '../config/constants.php';
require_once '../config/paths.php';
require_once '../config/settings.php';
require_once 'config.php';
require_once '../utils/helpers.php';
require_once '../utils/validators.php';
require_once '../middleware/auth.php';

header('Content-Type: application/json');

$method = getMethod();
$action = $_GET['action'] ?? '';

if (in_array($action, ['me', 'update-profile', 'change-password'])) {
    verifyToken();
}

switch ($action) {
    case 'register':
        registerUser();
        break;
    case 'login':
        loginUser();
        break;
    case 'logout':
        logoutUser();
        break;
    case 'verify':
        verifyEmail();
        break;
    case 'refresh':
        refreshToken();
        break;
    case 'me':
        getCurrentUser();
        break;
    case 'update-profile':
        updateProfile();
        break;
    case 'change-password':
        changePassword();
        break;
    default:
        sendError('Invalid action', 400);
}

function getCurrentUser() {
    global $conn;
    validateMethod(['GET']);

    $userId = $_SESSION['user_id'];

    $stmt = $conn->prepare(
        "SELECT id, full_name, email, phone, role, status, profile_picture, bio, address, location,
                rating, total_donations, total_received, email_verified, created_at
         FROM users WHERE id = ?"
    );
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('User not found', 404);
    }

    $user = $result->fetch_assoc();
    $stmt->close();

    sendSuccess('Profile retrieved', $user);
}

function updateProfile() {
    global $conn;
    validateMethod(['POST', 'PUT']);

    $userId = $_SESSION['user_id'];
    $data = getRequestData();

    $fullName = isset($data['full_name']) ? sanitizeInput($data['full_name']) : null;
    $phone = isset($data['phone']) ? sanitizeInput($data['phone']) : null;
    $bio = isset($data['bio']) ? sanitizeInput($data['bio']) : null;
    $address = isset($data['address']) ? sanitizeInput($data['address']) : null;
    $location = isset($data['location']) ? sanitizeInput($data['location']) : null;

    $stmt = $conn->prepare(
        "UPDATE users SET full_name = COALESCE(?, full_name), phone = COALESCE(?, phone),
                bio = COALESCE(?, bio), address = COALESCE(?, address), location = COALESCE(?, location)
         WHERE id = ?"
    );
    $stmt->bind_param("sssssi", $fullName, $phone, $bio, $address, $location, $userId);

    if ($stmt->execute()) {
        logActivity($userId, 'profile_updated', 'User updated their profile');
        sendSuccess('Profile updated successfully');
    } else {
        sendError('Failed to update profile: ' . $conn->error, 500);
    }

    $stmt->close();
}

function changePassword() {
    global $conn;
    validateMethod(['POST']);

    $userId = $_SESSION['user_id'];
    $data = getRequestData();

    if (empty($data['current_password']) || empty($data['new_password'])) {
        sendError('Current and new password are required', 400);
    }

    if (strlen($data['new_password']) < MIN_PASSWORD_LENGTH) {
        sendError('New password must be at least ' . MIN_PASSWORD_LENGTH . ' characters', 400);
    }

    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if (!$user || !password_verify($data['current_password'], $user['password'])) {
        sendError('Current password is incorrect', 401);
    }

    $newHash = password_hash($data['new_password'], PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $newHash, $userId);

    if ($stmt->execute()) {
        logActivity($userId, 'password_changed', 'User changed their password');
        sendSuccess('Password changed successfully');
    } else {
        sendError('Failed to change password', 500);
    }

    $stmt->close();
}

function registerUser() {
    global $conn;
    validateMethod(['POST']);

    $data = getRequestData();

    if (empty($data['full_name']) || empty($data['email']) || empty($data['password']) || empty($data['account_type'])) {
        sendError('Missing required fields', 400);
    }

    if (!isValidEmail($data['email'])) {
        sendError('Invalid email format', 400);
    }

    if (!isValidPassword($data['password'])) {
        sendError('Password must be 6-128 characters', 400);
    }

    if (!isValidPhone($data['phone'] ?? '')) {
        sendError('Invalid phone format', 400);
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $data['email']);
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        sendError('Email already registered', 400);
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT id FROM users WHERE phone = ?");
    $stmt->bind_param("s", $data['phone']);
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        sendError('Phone number already registered', 400);
    }
    $stmt->close();

    $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);

    $query = "INSERT INTO users (full_name, email, phone, role, password, status, created_at)
              VALUES (?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $conn->prepare($query);
    $status = 'active';
    $stmt->bind_param(
        "ssssss",
        $data['full_name'],
        $data['email'],
        $data['phone'],
        $data['account_type'],
        $hashedPassword,
        $status
    );

    if ($stmt->execute()) {
        $userId = $conn->insert_id;

        $tokenData = [
            'id' => $userId,
            'email' => $data['email'],
            'role' => $data['account_type'],
            'full_name' => $data['full_name']
        ];

        $token = generateJWT($tokenData);

        logActivity($userId, 'user_registered', 'New user registered');

        sendSuccess('User registered successfully', [
            'user_id' => $userId,
            'token' => $token,
            'role' => $data['account_type'],
            'full_name' => $data['full_name']
        ]);
    } else {
        sendError('Registration failed: ' . $conn->error, 500);
    }

    $stmt->close();
}

function loginUser() {
    global $conn;
    validateMethod(['POST']);

    $data = getRequestData();

    if (empty($data['email']) || empty($data['password'])) {
        sendError('Email and password required', 400);
    }

    $stmt = $conn->prepare(
        "SELECT id, full_name, email, role, password, status FROM users WHERE email = ?"
    );
    $stmt->bind_param("s", $data['email']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Invalid credentials', 401);
    }

    $user = $result->fetch_assoc();
    $stmt->close();

    if (!password_verify($data['password'], $user['password'])) {
        sendError('Invalid credentials', 401);
    }

    if ($user['status'] !== 'active') {
        sendError('Account is inactive', 403);
    }

    $tokenData = [
        'id' => $user['id'],
        'email' => $user['email'],
        'role' => $user['role'],
        'full_name' => $user['full_name']
    ];

    $token = generateJWT($tokenData);

    logActivity($user['id'], 'user_login', 'User logged in');

    sendSuccess('Login successful', [
        'user_id' => $user['id'],
        'token' => $token,
        'role' => $user['role'],
        'full_name' => $user['full_name'],
        'email' => $user['email']
    ]);
}

function logoutUser() {
    validateMethod(['POST']);

    sendSuccess('Logged out successfully');
}

function verifyEmail() {
    global $conn;
    validateMethod(['POST']);

    $data = getRequestData();

    if (empty($data['token'])) {
        sendError('Verification token required', 400);
    }

    $stmt = $conn->prepare(
        "SELECT user_id FROM verification_tokens WHERE token = ? AND type = 'email' AND expires_at > NOW()"
    );
    $stmt->bind_param("s", $data['token']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Invalid or expired verification token', 400);
    }

    $row = $result->fetch_assoc();
    $stmt->close();

    $updateStmt = $conn->prepare("UPDATE users SET is_verified = 1 WHERE id = ?");
    $updateStmt->bind_param("i", $row['user_id']);
    $updateStmt->execute();
    $updateStmt->close();

    $deleteStmt = $conn->prepare("DELETE FROM verification_tokens WHERE token = ?");
    $deleteStmt->bind_param("s", $data['token']);
    $deleteStmt->execute();
    $deleteStmt->close();

    sendSuccess('Email verified successfully');
}

function refreshToken() {
    global $conn;
    validateMethod(['POST']);

    $data = getRequestData();

    if (empty($data['token'])) {
        sendError('Token required', 400);
    }

    $payload = verifyJWT($data['token']);

    if (!$payload) {
        sendError('Invalid token', 401);
    }

    $newToken = generateJWT([
        'id' => $payload['id'],
        'email' => $payload['email'],
        'role' => $payload['role'],
        'full_name' => $payload['full_name']
    ]);

    sendSuccess('Token refreshed', ['token' => $newToken]);
}

?>