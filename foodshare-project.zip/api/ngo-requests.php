<?php

require_once '../config/constants.php';
require_once '../config/paths.php';
require_once '../config/settings.php';
require_once 'config.php';
require_once '../middleware/auth.php';
require_once '../utils/helpers.php';

header('Content-Type: application/json');

$method = getMethod();
$action = $_GET['action'] ?? '';

verifyToken();
requireRole('ngo');

switch ($action) {
    case 'list':
        ngoListRequests();
        break;
    case 'get':
        ngoGetRequest();
        break;
    case 'create':
        ngoCreateRequest();
        break;
    case 'cancel':
        ngoCancelRequest();
        break;
    default:
        sendError('Invalid action', 400);
}

function ngoListRequests() {
    global $conn;

    validateMethod(['GET']);

    $userId = $_SESSION['user_id'];
    $status = $_GET['status'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $query = "SELECT r.*, d.title, d.quantity, d.location, d.donor_id, u.full_name as donor_name,
                     dl.id as delivery_id, dl.status as delivery_status, dl.pickup_time as delivery_pickup_time,
                     dl.volunteer_id as delivery_volunteer_id, vol.full_name as volunteer_name,
                     EXISTS(SELECT 1 FROM reviews rv WHERE rv.request_id = r.id AND rv.reviewer_id = ?) as already_reviewed
              FROM requests r
              JOIN donations d ON r.donation_id = d.id
              JOIN users u ON d.donor_id = u.id
              LEFT JOIN deliveries dl ON dl.request_id = r.id
              LEFT JOIN users vol ON dl.volunteer_id = vol.id
              WHERE r.recipient_id = ?";

    $params = [$userId, $userId];

    if (!empty($status)) {
        $query .= " AND r.status = ?";
        $params[] = $status;
    }

    $query .= " ORDER BY r.created_at DESC LIMIT ? OFFSET ?";
    $params[] = $perPage;
    $params[] = $offset;

    $types = str_repeat("s", count($params) - 2) . "ii";

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $requests = [];
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
    $stmt->close();

    sendSuccess('Requests retrieved', $requests);
}

function ngoGetRequest() {
    global $conn;

    validateMethod(['GET']);

    $id = $_GET['id'] ?? null;

    if (!$id) {
        sendError('Request ID required', 400);
    }

    $query = "SELECT r.*, d.title, d.description, d.quantity, d.location, d.pickup_time,
                     u.full_name as donor_name, u.email, u.phone
              FROM requests r
              JOIN donations d ON r.donation_id = d.id
              JOIN users u ON d.donor_id = u.id
              WHERE r.id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Request not found', 404);
    }

    $request = $result->fetch_assoc();
    $stmt->close();

    sendSuccess('Request retrieved', $request);
}

function ngoCreateRequest() {
    global $conn;

    validateMethod(['POST']);

    $data = getRequestData();
    $userId = $_SESSION['user_id'];

    if (empty($data['donation_id'])) {
        sendError('Donation ID required', 400);
    }

    $donationStmt = $conn->prepare("SELECT donor_id, status FROM donations WHERE id = ?");
    $donationStmt->bind_param("i", $data['donation_id']);
    $donationStmt->execute();
    $donationResult = $donationStmt->get_result();

    if ($donationResult->num_rows === 0) {
        sendError('Donation not found', 404);
    }

    $donation = $donationResult->fetch_assoc();
    $donationStmt->close();

    if ((int)$donation['donor_id'] === (int)$userId) {
        sendError('You cannot request your own donation', 400);
    }

    if ($donation['status'] !== STATUS_AVAILABLE) {
        sendError('This donation is no longer available', 400);
    }

    $stmt = $conn->prepare(
        "SELECT id FROM requests WHERE donation_id = ? AND recipient_id = ? AND status != ?"
    );
    $rejected = REQ_REJECTED;
    $stmt->bind_param("iis", $data['donation_id'], $userId, $rejected);
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        sendError('You already have a pending request for this donation', 400);
    }
    $stmt->close();

    $query = "INSERT INTO requests (donation_id, recipient_id, status, message, created_at)
              VALUES (?, ?, ?, ?, NOW())";

    $stmt = $conn->prepare($query);
    $status = REQ_PENDING;
    $message = $data['message'] ?? null;
    $stmt->bind_param("iiss", $data['donation_id'], $userId, $status, $message);

    if ($stmt->execute()) {
        $requestId = $conn->insert_id;

        $updateStmt = $conn->prepare("UPDATE donations SET status = ? WHERE id = ?");
        $newStatus = STATUS_REQUESTED;
        $updateStmt->bind_param("si", $newStatus, $data['donation_id']);
        $updateStmt->execute();
        $updateStmt->close();

        createNotification(
            $donation['donor_id'],
            'New request received',
            'Someone requested your donation. Review it from your dashboard.',
            'request_received',
            $requestId,
            'request'
        );

        logActivity($userId, 'request_created', 'Requested donation #' . $data['donation_id']);

        sendSuccess('Request created successfully', ['request_id' => $requestId]);
    } else {
        sendError('Failed to create request', 500);
    }

    $stmt->close();
}

function ngoCancelRequest() {
    global $conn;

    validateMethod(['POST']);

    $data = getRequestData();
    $userId = $_SESSION['user_id'];
    $requestId = $data['id'] ?? null;

    if (!$requestId) {
        sendError('Request ID required', 400);
    }

    $stmt = $conn->prepare("SELECT donation_id, status FROM requests WHERE id = ? AND recipient_id = ?");
    $stmt->bind_param("ii", $requestId, $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Request not found or not authorized', 404);
    }

    $request = $result->fetch_assoc();
    $stmt->close();

    if ($request['status'] !== REQ_PENDING) {
        sendError('Only pending requests can be cancelled', 400);
    }

    $updateStmt = $conn->prepare("UPDATE requests SET status = ?, updated_at = NOW() WHERE id = ?");
    $status = REQ_REJECTED;
    $updateStmt->bind_param("si", $status, $requestId);
    $updateStmt->execute();
    $updateStmt->close();

    $donationStmt = $conn->prepare(
        "UPDATE donations SET status = ?, updated_at = NOW() WHERE id = ? AND status IN (?, ?)"
    );
    $donStatus = STATUS_AVAILABLE;
    $requested = STATUS_REQUESTED;
    $accepted = STATUS_ACCEPTED;
    $donationStmt->bind_param("siss", $donStatus, $request['donation_id'], $requested, $accepted);
    $donationStmt->execute();
    $donationStmt->close();

    logActivity($userId, 'request_cancelled', 'Cancelled request #' . $requestId);
    sendSuccess('Request cancelled successfully');
}

?>
