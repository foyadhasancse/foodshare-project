<?php

require_once '../config/constants.php';
require_once '../config/paths.php';
require_once '../config/settings.php';
require_once 'config.php';
require_once '../middleware/auth.php';
require_once '../utils/helpers.php';

header('Content-Type: application/json');

$method = getMethod();
$action = $_GET['action'] ?? '';

verifyToken();

switch ($action) {
    case 'list':
        listDeliveries();
        break;
    case 'get':
        getDelivery();
        break;
    case 'accept':
        acceptDelivery();
        break;
    case 'complete':
        confirmReceived();
        break;
    case 'track':
        trackDelivery();
        break;
    case 'available':
        availableDeliveries();
        break;
    case 'pickup':
        markPickedUp();
        break;
    default:
        sendError('Invalid action', 400);
}

function availableDeliveries() {
    global $conn;
    validateMethod(['GET']);

    $query = "SELECT dl.*, r.id as request_id, do.title as donation_title, do.quantity,
                     u.full_name as donor_name
              FROM deliveries dl
              JOIN requests r ON dl.request_id = r.id
              JOIN donations do ON r.donation_id = do.id
              JOIN users u ON do.donor_id = u.id
              WHERE dl.volunteer_id IS NULL AND dl.status = 'pending'
              ORDER BY dl.scheduled_time ASC
              LIMIT 50";

    $result = $conn->query($query);
    $deliveries = [];
    while ($row = $result->fetch_assoc()) {
        $deliveries[] = $row;
    }

    sendSuccess('Available jobs retrieved', $deliveries);
}

function listDeliveries() {
    global $conn;
    validateMethod(['GET']);

    $volunteerId = $_SESSION['user_id'];
    $status = $_GET['status'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $query = "SELECT d.*, r.id as request_id, do.title as donation_title, do.quantity,
                     u.full_name as donor_name, u.phone
              FROM deliveries d
              JOIN requests r ON d.request_id = r.id
              JOIN donations do ON r.donation_id = do.id
              JOIN users u ON do.donor_id = u.id
              WHERE d.volunteer_id = ?";

    $params = [$volunteerId];

    if (!empty($status)) {
        $query .= " AND d.status = ?";
        $params[] = $status;
    }

    $query .= " ORDER BY d.scheduled_time DESC LIMIT ? OFFSET ?";
    $params[] = $perPage;
    $params[] = $offset;

    $types = str_repeat("s", count($params) - 2) . "ii";

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $deliveries = [];
    while ($row = $result->fetch_assoc()) {
        $deliveries[] = $row;
    }
    $stmt->close();

    sendSuccess('Deliveries retrieved', $deliveries);
}

function getDelivery() {
    global $conn;
    validateMethod(['GET']);

    $id = $_GET['id'] ?? null;
    if (!$id) {
        sendError('Delivery ID required', 400);
    }

    $query = "SELECT d.*, r.id as request_id, u.full_name as donor_name, u.phone,
                     rec.full_name as recipient_name, rec.phone as recipient_phone,
                     do.title, do.quantity, do.location
              FROM deliveries d
              JOIN requests r ON d.request_id = r.id
              JOIN donations do ON r.donation_id = do.id
              JOIN users u ON do.donor_id = u.id
              JOIN users rec ON r.recipient_id = rec.id
              WHERE d.id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Delivery not found', 404);
    }

    $delivery = $result->fetch_assoc();
    $stmt->close();

    sendSuccess('Delivery retrieved', $delivery);
}

function acceptDelivery() {
    global $conn;
    validateMethod(['POST']);

    $data = getRequestData();
    $volunteerId = $_SESSION['user_id'];
    $deliveryId = $data['id'] ?? null;

    if (!$deliveryId) {
        sendError('Delivery ID required', 400);
    }

    $checkStmt = $conn->prepare(
        "SELECT dl.id, r.recipient_id, do.donor_id, do.title
         FROM deliveries dl
         JOIN requests r ON dl.request_id = r.id
         JOIN donations do ON r.donation_id = do.id
         WHERE dl.id = ? AND dl.status = 'pending' AND dl.volunteer_id IS NULL"
    );
    $checkStmt->bind_param("i", $deliveryId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows === 0) {
        sendError('This delivery job is no longer available', 400);
    }

    $job = $checkResult->fetch_assoc();
    $checkStmt->close();

    $query = "UPDATE deliveries SET status = ?, volunteer_id = ?, updated_at = NOW() WHERE id = ?";
    $stmt = $conn->prepare($query);
    $status = 'in_progress';
    $stmt->bind_param("sii", $status, $volunteerId, $deliveryId);

    if ($stmt->execute()) {
        logActivity($volunteerId, 'delivery_accepted', 'Accepted delivery job #' . $deliveryId);

        $volunteer = getUserById($volunteerId);
        $volunteerName = $volunteer['full_name'] ?? 'A volunteer';

        createNotification(
            $job['donor_id'],
            'Volunteer assigned',
            $volunteerName . ' will handle pickup for "' . $job['title'] . '".',
            'delivery_assigned',
            $deliveryId,
            'delivery'
        );
        createNotification(
            $job['recipient_id'],
            'Delivery scheduled',
            $volunteerName . ' will deliver your donation soon.',
            'delivery_assigned',
            $deliveryId,
            'delivery'
        );

        sendSuccess('Delivery accepted');
    } else {
        sendError('Failed to accept delivery', 500);
    }

    $stmt->close();
}

function markPickedUp() {
    global $conn;
    validateMethod(['POST']);

    $data = getRequestData();
    $volunteerId = $_SESSION['user_id'];
    $deliveryId = $data['id'] ?? null;

    if (!$deliveryId) {
        sendError('Delivery ID required', 400);
    }

    $checkStmt = $conn->prepare(
        "SELECT dl.pickup_time, r.recipient_id, r.donation_id, do.donor_id, do.title
         FROM deliveries dl
         JOIN requests r ON dl.request_id = r.id
         JOIN donations do ON r.donation_id = do.id
         WHERE dl.id = ? AND dl.volunteer_id = ? AND dl.status = 'in_progress'"
    );
    $checkStmt->bind_param("ii", $deliveryId, $volunteerId);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows === 0) {
        sendError('Delivery not found or not assigned to you', 404);
    }

    $job = $checkResult->fetch_assoc();
    $checkStmt->close();

    if ($job['pickup_time'] !== null) {
        sendError('This delivery has already been picked up', 400);
    }

    $stmt = $conn->prepare("UPDATE deliveries SET pickup_time = NOW(), updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $deliveryId);

    if ($stmt->execute()) {

        $donStmt = $conn->prepare("UPDATE donations SET status = ?, updated_at = NOW() WHERE id = ?");
        $pickedUpStatus = STATUS_PICKED_UP;
        $donStmt->bind_param("si", $pickedUpStatus, $job['donation_id']);
        $donStmt->execute();
        $donStmt->close();

        logActivity($volunteerId, 'delivery_picked_up', 'Picked up delivery #' . $deliveryId);

        createNotification(
            $job['recipient_id'],
            'Your delivery is on the way',
            'The volunteer has picked up "' . $job['title'] . '" and is heading your way.',
            'delivery_picked_up',
            $deliveryId,
            'delivery'
        );
        createNotification(
            $job['donor_id'],
            'Donation picked up',
            'The volunteer has picked up "' . $job['title'] . '" for delivery.',
            'delivery_picked_up',
            $deliveryId,
            'delivery'
        );

        sendSuccess('Marked as picked up');
    } else {
        sendError('Failed to update delivery', 500);
    }

    $stmt->close();
}

function confirmReceived() {
    global $conn;
    validateMethod(['POST']);

    $data = getRequestData();
    $userId = $_SESSION['user_id'];
    $deliveryId = $data['id'] ?? null;

    if (!$deliveryId) {
        sendError('Delivery ID required', 400);
    }

    $ownStmt = $conn->prepare(
        "SELECT dl.request_id, dl.status as delivery_status, dl.volunteer_id, dl.pickup_time,
                r.donation_id, r.recipient_id, do.donor_id, do.title
         FROM deliveries dl
         JOIN requests r ON dl.request_id = r.id
         JOIN donations do ON r.donation_id = do.id
         WHERE dl.id = ? AND r.recipient_id = ?"
    );
    $ownStmt->bind_param("ii", $deliveryId, $userId);
    $ownStmt->execute();
    $ownResult = $ownStmt->get_result();

    if ($ownResult->num_rows === 0) {
        sendError('Delivery not found or not authorized', 404);
    }

    $job = $ownResult->fetch_assoc();
    $ownStmt->close();

    if ($job['delivery_status'] !== 'in_progress' || !$job['volunteer_id']) {
        sendError('This delivery has not been picked up by a volunteer yet', 400);
    }

    if (empty($job['pickup_time'])) {
        sendError('The volunteer has not marked this delivery as picked up yet', 400);
    }

    $query = "UPDATE deliveries SET status = ?, delivery_time = NOW(), notes = ?, updated_at = NOW() WHERE id = ?";
    $stmt = $conn->prepare($query);
    $status = 'completed';
    $notes = $data['notes'] ?? null;
    $stmt->bind_param("ssi", $status, $notes, $deliveryId);

    if ($stmt->execute()) {
        $updateReqStmt = $conn->prepare("UPDATE requests SET status = ? WHERE id = ?");
        $reqStatus = REQ_COMPLETED;
        $updateReqStmt->bind_param("si", $reqStatus, $job['request_id']);
        $updateReqStmt->execute();
        $updateReqStmt->close();

        $updateDonStmt = $conn->prepare("UPDATE donations SET status = ?, updated_at = NOW() WHERE id = ?");
        $donStatus = STATUS_COMPLETED;
        $updateDonStmt->bind_param("si", $donStatus, $job['donation_id']);
        $updateDonStmt->execute();
        $updateDonStmt->close();

        createNotification(
            $job['donor_id'],
            'Donation received',
            'The recipient confirmed receiving "' . $job['title'] . '". You can now leave each other a review.',
            'delivery_completed',
            $deliveryId,
            'delivery'
        );
        createNotification(
            $job['volunteer_id'],
            'Delivery confirmed',
            'The recipient confirmed receiving "' . $job['title'] . '". Thanks for delivering!',
            'delivery_completed',
            $deliveryId,
            'delivery'
        );

        logActivity($userId, 'delivery_confirmed', 'Confirmed receipt of delivery #' . $deliveryId);
        sendSuccess('Delivery marked as received');
    } else {
        sendError('Failed to confirm delivery', 500);
    }

    $stmt->close();
}

function trackDelivery() {
    global $conn;
    validateMethod(['GET']);

    $id = $_GET['id'] ?? null;
    if (!$id) {
        sendError('Delivery ID required', 400);
    }

    $stmt = $conn->prepare("SELECT id, status, scheduled_time, pickup_time, delivery_time, latitude, longitude FROM deliveries WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Delivery not found', 404);
    }

    $delivery = $result->fetch_assoc();
    $stmt->close();

    sendSuccess('Delivery tracking info', $delivery);
}

?>