<?php

require_once '../config/constants.php';
require_once '../config/paths.php';
require_once '../config/settings.php';
require_once 'config.php';
require_once '../middleware/auth.php';
require_once '../utils/helpers.php';

header('Content-Type: application/json');

$method = getMethod();
$action = $_GET['action'] ?? '';

if (in_array($action, ['create', 'update', 'delete'])) {
    verifyToken();
}

switch ($action) {
    case 'list':
        listDonations();
        break;
    case 'get':
        getDonation();
        break;
    case 'create':
        createDonation();
        break;
    case 'update':
        updateDonation();
        break;
    case 'delete':
        deleteDonation();
        break;
    case 'search':
        searchDonations();
        break;
    default:
        sendError('Invalid action', 400);
}

function listDonations() {
    global $conn;

    validateMethod(['GET']);

    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;
    $status = $_GET['status'] ?? STATUS_AVAILABLE;
    $donorId = $_GET['donor_id'] ?? null;

    $where = [];
    $params = [];
    $types = '';

    if (!empty($status) && $status !== 'all') {
        $where[] = "d.status = ?";
        $params[] = $status;
        $types .= 's';
    }

    if (!empty($donorId)) {
        $where[] = "d.donor_id = ?";
        $params[] = (int)$donorId;
        $types .= 'i';
    }

    $whereSql = count($where) ? ('WHERE ' . implode(' AND ', $where)) : '';

    $countQuery = "SELECT COUNT(*) as total FROM donations d $whereSql";
    $stmt = $conn->prepare($countQuery);
    if (count($params)) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $total = $stmt->get_result()->fetch_assoc()['total'];
    $stmt->close();

    $query = "SELECT d.*, u.full_name as donor_name, u.phone
              FROM donations d
              JOIN users u ON d.donor_id = u.id
              $whereSql
              ORDER BY d.created_at DESC
              LIMIT ? OFFSET ?";

    $stmt = $conn->prepare($query);
    $allParams = array_merge($params, [$perPage, $offset]);
    $allTypes = $types . 'ii';
    $stmt->bind_param($allTypes, ...$allParams);
    $stmt->execute();
    $result = $stmt->get_result();

    $donations = [];
    while ($row = $result->fetch_assoc()) {
        $donations[] = $row;
    }
    $stmt->close();

    $pagination = [
        'current_page' => $page,
        'per_page' => $perPage,
        'total' => $total,
        'total_pages' => ceil($total / $perPage)
    ];

    sendSuccess('Donations retrieved', $donations, $pagination);
}

function getDonation() {
    global $conn;

    validateMethod(['GET']);

    $id = $_GET['id'] ?? null;

    if (!$id) {
        sendError('Donation ID required', 400);
    }

    $query = "SELECT d.*, u.full_name as donor_name, u.email, u.phone, u.rating
              FROM donations d
              JOIN users u ON d.donor_id = u.id
              WHERE d.id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Donation not found', 404);
    }

    $donation = $result->fetch_assoc();
    $stmt->close();

    sendSuccess('Donation retrieved', $donation);
}

function createDonation() {
    global $conn;

    validateMethod(['POST']);

    $data = getRequestData();
    $userId = $_SESSION['user_id'] ?? null;

    $required = ['title', 'description', 'quantity', 'location', 'pickup_time'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            sendError("$field is required", 400);
        }
    }

    $query = "INSERT INTO donations
              (donor_id, title, description, quantity, location, pickup_time, expires_at, status, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $conn->prepare($query);

    $status = STATUS_AVAILABLE;
    $expiresAt = date('Y-m-d H:i:s', strtotime($data['pickup_time'] . ' +4 hours'));

    $stmt->bind_param(
        "isssssss",
        $userId,
        $data['title'],
        $data['description'],
        $data['quantity'],
        $data['location'],
        $data['pickup_time'],
        $expiresAt,
        $status
    );

    if ($stmt->execute()) {
        $donationId = $conn->insert_id;

        logActivity($userId, 'donation_created', 'Created donation: ' . $data['title']);

        sendSuccess('Donation created successfully', ['donation_id' => $donationId]);
    } else {
        sendError('Failed to create donation: ' . $conn->error, 500);
    }

    $stmt->close();
}

function updateDonation() {
    global $conn;

    validateMethod(['PUT', 'POST']);

    $data = getRequestData();
    $userId = $_SESSION['user_id'] ?? null;
    $donationId = $data['id'] ?? null;

    if (!$donationId) {
        sendError('Donation ID required', 400);
    }

    $stmt = $conn->prepare("SELECT donor_id FROM donations WHERE id = ?");
    $stmt->bind_param("i", $donationId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Donation not found', 404);
    }

    $donation = $result->fetch_assoc();
    $stmt->close();

    if ($donation['donor_id'] !== $userId) {
        sendError('Unauthorized', 403);
    }

    $query = "UPDATE donations SET
              title = ?, description = ?, quantity = ?, location = ?, updated_at = NOW()
              WHERE id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param(
        "ssssi",
        $data['title'] ?? null,
        $data['description'] ?? null,
        $data['quantity'] ?? null,
        $data['location'] ?? null,
        $donationId
    );

    if ($stmt->execute()) {
        sendSuccess('Donation updated successfully');
    } else {
        sendError('Failed to update donation', 500);
    }

    $stmt->close();
}

function deleteDonation() {
    global $conn;

    validateMethod(['DELETE', 'POST']);

    $data = getRequestData();
    $userId = $_SESSION['user_id'] ?? null;
    $donationId = $data['id'] ?? null;

    if (!$donationId) {
        sendError('Donation ID required', 400);
    }

    $stmt = $conn->prepare("SELECT donor_id FROM donations WHERE id = ?");
    $stmt->bind_param("i", $donationId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Donation not found', 404);
    }

    $donation = $result->fetch_assoc();
    $stmt->close();

    if ($donation['donor_id'] !== $userId) {
        sendError('Unauthorized', 403);
    }

    $stmt = $conn->prepare("DELETE FROM donations WHERE id = ?");
    $stmt->bind_param("i", $donationId);

    if ($stmt->execute()) {
        sendSuccess('Donation deleted successfully');
    } else {
        sendError('Failed to delete donation', 500);
    }

    $stmt->close();
}

function searchDonations() {
    global $conn;

    validateMethod(['GET']);

    $query = $_GET['q'] ?? '';
    $location = $_GET['location'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $searchQuery = "SELECT d.*, u.full_name as donor_name
                    FROM donations d
                    JOIN users u ON d.donor_id = u.id
                    WHERE d.status = ? AND (d.title LIKE ? OR d.description LIKE ?)";

    $params = [STATUS_AVAILABLE, "%$query%", "%$query%"];

    if (!empty($location)) {
        $searchQuery .= " AND d.location LIKE ?";
        $params[] = "%$location%";
    }

    $searchQuery .= " ORDER BY d.created_at DESC LIMIT ? OFFSET ?";
    $params[] = $perPage;
    $params[] = $offset;

    $stmt = $conn->prepare($searchQuery);

    $types = str_repeat("s", count($params) - 2) . "ii";
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $donations = [];
    while ($row = $result->fetch_assoc()) {
        $donations[] = $row;
    }
    $stmt->close();

    $pagination = [
        'current_page' => $page,
        'per_page' => $perPage,
        'total' => count($donations)
    ];

    sendSuccess('Search results', $donations, $pagination);
}

?>