<?php

require_once '../config/constants.php';
require_once '../config/paths.php';
require_once '../config/settings.php';
require_once 'config.php';
require_once '../middleware/auth.php';
require_once '../utils/helpers.php';

header('Content-Type: application/json');

$method = getMethod();
$action = $_GET['action'] ?? '';

verifyToken();
requireRole('ngo');

switch ($action) {
    case 'list':
        ngoListDonations();
        break;
    case 'get':
        ngoGetDonation();
        break;
    case 'search':
        ngoSearchDonations();
        break;
    default:
        sendError('Invalid action', 400);
}

function ngoListDonations() {
    global $conn;

    validateMethod(['GET']);

    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;
    $status = $_GET['status'] ?? STATUS_AVAILABLE;
    $donorId = $_GET['donor_id'] ?? null;

    $where = [];
    $params = [];
    $types = '';

    if (!empty($status) && $status !== 'all') {
        $where[] = "d.status = ?";
        $params[] = $status;
        $types .= 's';
    }

    if (!empty($donorId)) {
        $where[] = "d.donor_id = ?";
        $params[] = (int)$donorId;
        $types .= 'i';
    }

    $whereSql = count($where) ? ('WHERE ' . implode(' AND ', $where)) : '';

    $countQuery = "SELECT COUNT(*) as total FROM donations d $whereSql";
    $stmt = $conn->prepare($countQuery);
    if (count($params)) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $total = $stmt->get_result()->fetch_assoc()['total'];
    $stmt->close();

    $query = "SELECT d.*, u.full_name as donor_name, u.phone
              FROM donations d
              JOIN users u ON d.donor_id = u.id
              $whereSql
              ORDER BY d.created_at DESC
              LIMIT ? OFFSET ?";

    $stmt = $conn->prepare($query);
    $allParams = array_merge($params, [$perPage, $offset]);
    $allTypes = $types . 'ii';
    $stmt->bind_param($allTypes, ...$allParams);
    $stmt->execute();
    $result = $stmt->get_result();

    $donations = [];
    while ($row = $result->fetch_assoc()) {
        $donations[] = $row;
    }
    $stmt->close();

    $pagination = [
        'current_page' => $page,
        'per_page' => $perPage,
        'total' => $total,
        'total_pages' => ceil($total / $perPage)
    ];

    sendSuccess('Donations retrieved', $donations, $pagination);
}

function ngoGetDonation() {
    global $conn;

    validateMethod(['GET']);

    $id = $_GET['id'] ?? null;

    if (!$id) {
        sendError('Donation ID required', 400);
    }

    $query = "SELECT d.*, u.full_name as donor_name, u.email, u.phone, u.rating
              FROM donations d
              JOIN users u ON d.donor_id = u.id
              WHERE d.id = ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        sendError('Donation not found', 404);
    }

    $donation = $result->fetch_assoc();
    $stmt->close();

    sendSuccess('Donation retrieved', $donation);
}

function ngoSearchDonations() {
    global $conn;

    validateMethod(['GET']);

    $query = $_GET['q'] ?? '';
    $location = $_GET['location'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $searchQuery = "SELECT d.*, u.full_name as donor_name
                    FROM donations d
                    JOIN users u ON d.donor_id = u.id
                    WHERE d.status = ? AND (d.title LIKE ? OR d.description LIKE ?)";

    $params = [STATUS_AVAILABLE, "%$query%", "%$query%"];

    if (!empty($location)) {
        $searchQuery .= " AND d.location LIKE ?";
        $params[] = "%$location%";
    }

    $searchQuery .= " ORDER BY d.created_at DESC LIMIT ? OFFSET ?";
    $params[] = $perPage;
    $params[] = $offset;

    $stmt = $conn->prepare($searchQuery);

    $types = str_repeat("s", count($params) - 2) . "ii";
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $donations = [];
    while ($row = $result->fetch_assoc()) {
        $donations[] = $row;
    }
    $stmt->close();

    $pagination = [
        'current_page' => $page,
        'per_page' => $perPage,
        'total' => count($donations)
    ];

    sendSuccess('Search results', $donations, $pagination);
}

?>
