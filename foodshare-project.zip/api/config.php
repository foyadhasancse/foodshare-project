<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'foodshare');
define('DB_PORT', 3306);
define('DB_CHARSET', 'utf8mb4');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, DB_PORT);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit;
}

$conn->set_charset(DB_CHARSET);

if (APP_ENV === 'development') {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
}

function sendResponse($success, $message, $data = null, $pagination = null, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');

    $response = [
        'success' => $success,
        'message' => $message
    ];

    if ($data !== null) {
        $response['data'] = $data;
    }

    if ($pagination !== null) {
        $response['pagination'] = $pagination;
    }

    echo json_encode($response);
    exit;
}

function sendSuccess($message, $data = null, $pagination = null) {
    sendResponse(true, $message, $data, $pagination, 200);
}

function sendError($message, $statusCode = 400) {
    sendResponse(false, $message, null, null, $statusCode);
}

function getMethod() {
    return $_SERVER['REQUEST_METHOD'];
}

function getRequestData() {
    $data = json_decode(file_get_contents('php://input'), true);
    return $data ?? [];
}

function validateMethod($allowedMethods) {
    $method = getMethod();
    if (!in_array($method, $allowedMethods)) {
        sendError('Method not allowed', 405);
    }
}

?>