<?php

require_once '../config/constants.php';
require_once '../config/paths.php';
require_once '../config/settings.php';
require_once 'config.php';
require_once '../middleware/auth.php';
require_once '../utils/helpers.php';

header('Content-Type: application/json');

$method = getMethod();
$action = $_GET['action'] ?? '';

verifyToken();

switch ($action) {
    case 'list':
        listNotifications();
        break;
    case 'unread-count':
        unreadCount();
        break;
    case 'mark-read':
        markRead();
        break;
    case 'mark-all-read':
        markAllRead();
        break;
    case 'delete':
        deleteNotification();
        break;
    default:
        sendError('Invalid action', 400);
}

function listNotifications() {
    global $conn;
    validateMethod(['GET']);

    $userId = $_SESSION['user_id'];
    $filter = $_GET['filter'] ?? 'all';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $query = "SELECT * FROM notifications WHERE user_id = ?";
    $params = [$userId];
    $types = 'i';

    if ($filter === 'unread') {
        $query .= " AND is_read = 0";
    }

    $query .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params[] = $perPage;
    $params[] = $offset;
    $types .= 'ii';

    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();

    sendSuccess('Notifications retrieved', $notifications);
}

function unreadCount() {
    global $conn;
    validateMethod(['GET']);

    $userId = $_SESSION['user_id'];

    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    sendSuccess('Unread count retrieved', ['count' => (int)$row['count']]);
}

function markRead() {
    global $conn;
    validateMethod(['POST', 'PUT']);

    $userId = $_SESSION['user_id'];
    $data = getRequestData();
    $id = $data['id'] ?? null;

    if (!$id) {
        sendError('Notification ID required', 400);
    }

    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $userId);

    if ($stmt->execute()) {
        sendSuccess('Notification marked as read');
    } else {
        sendError('Failed to update notification', 500);
    }

    $stmt->close();
}

function markAllRead() {
    global $conn;
    validateMethod(['POST', 'PUT']);

    $userId = $_SESSION['user_id'];

    $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
    $stmt->bind_param("i", $userId);

    if ($stmt->execute()) {
        sendSuccess('All notifications marked as read');
    } else {
        sendError('Failed to update notifications', 500);
    }

    $stmt->close();
}

function deleteNotification() {
    global $conn;
    validateMethod(['POST', 'DELETE']);

    $userId = $_SESSION['user_id'];
    $data = getRequestData();
    $id = $data['id'] ?? null;

    if (!$id) {
        sendError('Notification ID required', 400);
    }

    $stmt = $conn->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $userId);

    if ($stmt->execute()) {
        sendSuccess('Notification deleted');
    } else {
        sendError('Failed to delete notification', 500);
    }

    $stmt->close();
}

function createNotificationForUser($userId, $title, $message, $type = 'system', $referenceId = null, $referenceType = null) {
    global $conn;
    $stmt = $conn->prepare(
        "INSERT INTO notifications (user_id, title, message, type, reference_id, reference_type) VALUES (?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("isssis", $userId, $title, $message, $type, $referenceId, $referenceType);
    $stmt->execute();
    $stmt->close();
}
?>
