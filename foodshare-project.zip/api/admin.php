<?php

require_once '../config/constants.php';
require_once '../config/paths.php';
require_once '../config/settings.php';
require_once 'config.php';
require_once '../middleware/auth.php';
require_once '../utils/helpers.php';

header('Content-Type: application/json');

$method = getMethod();
$action = $_GET['action'] ?? '';

verifyToken();
requireRole(ROLE_ADMIN);

switch ($action) {
    case 'stats':
        getStats();
        break;
    case 'users':
        listUsers();
        break;
    case 'update-user-status':
        updateUserStatus();
        break;
    case 'donations':
        listAllDonations();
        break;
    case 'logs':
        getActivityLogs();
        break;
    default:
        sendError('Invalid action', 400);
}

function getStats() {
    global $conn;
    validateMethod(['GET']);

    $stats = [];

    $stats['total_users'] = (int)$conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
    $stats['total_donors'] = (int)$conn->query("SELECT COUNT(*) c FROM users WHERE role = 'donor'")->fetch_assoc()['c'];
    $stats['total_recipients'] = (int)$conn->query("SELECT COUNT(*) c FROM users WHERE role = 'recipient'")->fetch_assoc()['c'];
    $stats['total_volunteers'] = (int)$conn->query("SELECT COUNT(*) c FROM users WHERE role = 'volunteer'")->fetch_assoc()['c'];
    $stats['total_donations'] = (int)$conn->query("SELECT COUNT(*) c FROM donations")->fetch_assoc()['c'];
    $stats['active_donations'] = (int)$conn->query("SELECT COUNT(*) c FROM donations WHERE status = 'available'")->fetch_assoc()['c'];
    $stats['completed_donations'] = (int)$conn->query("SELECT COUNT(*) c FROM donations WHERE status = 'completed'")->fetch_assoc()['c'];
    $stats['total_requests'] = (int)$conn->query("SELECT COUNT(*) c FROM requests")->fetch_assoc()['c'];
    $stats['pending_requests'] = (int)$conn->query("SELECT COUNT(*) c FROM requests WHERE status = 'pending'")->fetch_assoc()['c'];
    $stats['total_deliveries'] = (int)$conn->query("SELECT COUNT(*) c FROM deliveries")->fetch_assoc()['c'];
    $stats['completed_deliveries'] = (int)$conn->query("SELECT COUNT(*) c FROM deliveries WHERE status = 'completed'")->fetch_assoc()['c'];
    $stats['suspended_users'] = (int)$conn->query("SELECT COUNT(*) c FROM users WHERE status = 'suspended'")->fetch_assoc()['c'];

    sendSuccess('Stats retrieved', $stats);
}

function listUsers() {
    global $conn;
    validateMethod(['GET']);

    $role = $_GET['role'] ?? '';
    $status = $_GET['status'] ?? '';
    $search = $_GET['q'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $where = [];
    $params = [];
    $types = '';

    if (!empty($role)) {
        $where[] = "role = ?";
        $params[] = $role;
        $types .= 's';
    }
    if (!empty($status)) {
        $where[] = "status = ?";
        $params[] = $status;
        $types .= 's';
    }
    if (!empty($search)) {
        $where[] = "(full_name LIKE ? OR email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $types .= 'ss';
    }

    $whereSql = count($where) ? ('WHERE ' . implode(' AND ', $where)) : '';

    $query = "SELECT id, full_name, email, phone, role, status, rating, total_donations,
                     total_received, created_at
              FROM users $whereSql
              ORDER BY created_at DESC LIMIT ? OFFSET ?";

    $stmt = $conn->prepare($query);
    $allParams = array_merge($params, [$perPage, $offset]);
    $allTypes = $types . 'ii';
    $stmt->bind_param($allTypes, ...$allParams);
    $stmt->execute();
    $result = $stmt->get_result();

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $stmt->close();

    sendSuccess('Users retrieved', $users);
}

function updateUserStatus() {
    global $conn;
    validateMethod(['POST', 'PUT']);

    $data = getRequestData();
    $userId = $data['id'] ?? null;
    $status = $data['status'] ?? null;

    if (!$userId || !in_array($status, ['active', 'inactive', 'suspended'])) {
        sendError('Valid user id and status are required', 400);
    }

    $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $userId);

    if ($stmt->execute()) {
        logActivity($_SESSION['user_id'], 'user_status_updated', "Set user #$userId status to $status");
        sendSuccess('User status updated');
    } else {
        sendError('Failed to update user status', 500);
    }

    $stmt->close();
}

function listAllDonations() {
    global $conn;
    validateMethod(['GET']);

    $status = $_GET['status'] ?? '';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? min((int)$_GET['per_page'], MAX_PER_PAGE) : DEFAULT_PER_PAGE;
    $offset = ($page - 1) * $perPage;

    $where = '';
    $params = [];
    $types = '';

    if (!empty($status)) {
        $where = 'WHERE d.status = ?';
        $params[] = $status;
        $types .= 's';
    }

    $query = "SELECT d.*, u.full_name as donor_name
              FROM donations d
              JOIN users u ON d.donor_id = u.id
              $where
              ORDER BY d.created_at DESC LIMIT ? OFFSET ?";

    $stmt = $conn->prepare($query);
    $allParams = array_merge($params, [$perPage, $offset]);
    $allTypes = $types . 'ii';
    $stmt->bind_param($allTypes, ...$allParams);
    $stmt->execute();
    $result = $stmt->get_result();

    $donations = [];
    while ($row = $result->fetch_assoc()) {
        $donations[] = $row;
    }
    $stmt->close();

    sendSuccess('Donations retrieved', $donations);
}

function getActivityLogs() {
    global $conn;
    validateMethod(['GET']);

    $limit = isset($_GET['limit']) ? min((int)$_GET['limit'], 200) : 50;

    $query = "SELECT al.*, u.full_name as user_name
              FROM activity_logs al
              LEFT JOIN users u ON al.user_id = u.id
              ORDER BY al.created_at DESC
              LIMIT ?";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();

    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    $stmt->close();

    sendSuccess('Activity logs retrieved', $logs);
}
?>
