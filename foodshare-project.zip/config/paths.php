<?php

define('BASE_PATH', dirname(dirname(__FILE__)));
define('CONFIG_PATH', BASE_PATH . '/config');
define('INCLUDES_PATH', BASE_PATH . '/includes');
define('API_PATH', BASE_PATH . '/api');
define('UTILS_PATH', BASE_PATH . '/utils');
define('MIDDLEWARE_PATH', BASE_PATH . '/middleware');
define('UPLOADS_PATH', BASE_PATH . '/uploads');
define('PUBLIC_PATH', BASE_PATH . '/public');

?>
