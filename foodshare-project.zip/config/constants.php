<?php

define('APP_NAME', 'FoodShare');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost/foodshare-project');
define('APP_ENV', 'development');

define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024);
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf']);
define('UPLOAD_DIR', __DIR__ . '/../uploads/');

define('FROM_EMAIL', 'noreply@foodshare.com');
define('FROM_NAME', 'FoodShare');

define('ROLE_DONOR', 'donor');
define('ROLE_RECIPIENT', 'recipient');
define('ROLE_NGO', 'ngo');
define('ROLE_VOLUNTEER', 'volunteer');
define('ROLE_ADMIN', 'admin');

define('STATUS_AVAILABLE', 'available');
define('STATUS_REQUESTED', 'requested');
define('STATUS_ACCEPTED', 'accepted');
define('STATUS_PICKED_UP', 'picked_up');
define('STATUS_COMPLETED', 'completed');
define('STATUS_CANCELLED', 'cancelled');

define('REQ_PENDING', 'pending');
define('REQ_ACCEPTED', 'accepted');
define('REQ_REJECTED', 'rejected');
define('REQ_COMPLETED', 'completed');

define('DEFAULT_PER_PAGE', 10);
define('MAX_PER_PAGE', 100);

define('MIN_PASSWORD_LENGTH', 6);
define('MAX_PASSWORD_LENGTH', 128);

?>
