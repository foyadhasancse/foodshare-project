/* ============================================
   DONOR DASHBOARD — data & logic (donor role only)
   ============================================ */

async function loadDonorDashboardData() {
    const userId = sessionStorage.getItem('user_id');

    const donationsEndpoint = `${API_BASE_URL}/donations.php?action=list&status=all&donor_id=${userId}&per_page=50`;
    const donationsResult = await apiCall(donationsEndpoint);

    if (donationsResult.success) {
        const donations = donationsResult.data;
        const active = donations.filter(d => ['available', 'requested', 'accepted', 'picked_up'].includes(d.status)).length;
        const completed = donations.filter(d => d.status === 'completed').length;

        setText('statTotal', donations.length);
        setText('statActive', active);
        setText('statCompleted', completed);

        renderMyDonations(donations);
    }

    const requestsEndpoint = `${API_BASE_URL}/requests.php?action=list&view=donor&per_page=50`;
    const requestsResult = await apiCall(requestsEndpoint);

    if (requestsResult.success) {
        const pendingCount = requestsResult.data.filter(r => r.status === 'pending').length;
        setText('statRequests', pendingCount);
        renderIncomingRequests(requestsResult.data);
    }
}

function renderMyDonations(donations) {
    const grid = document.getElementById('myDonationsGrid');
    if (!grid) return;

    if (!donations || donations.length === 0) {
        grid.innerHTML = `
            <div class="empty-state" style="grid-column:1/-1;">
                <i class="fas fa-box-open"></i>
                <p>You haven't posted any donations yet.</p>
            </div>`;
        return;
    }

    grid.innerHTML = donations.map(d => `
        <div class="donation-card" onclick="viewDonation(${d.id})">
            <div class="card-header">
                <h3>${escapeHtml(d.title)}</h3>
                <span class="status ${d.status}">${d.status.replace('_', ' ')}</span>
            </div>
            <div class="card-body">
                <p><strong>Quantity:</strong> ${escapeHtml(d.quantity)}</p>
                <p><strong>Location:</strong> ${escapeHtml(d.location)}</p>
                <p class="description">${escapeHtml(d.description)}</p>
            </div>
            <div class="card-footer">
                <span class="time-ago">${timeAgo(d.created_at)}</span>
                <button class="btn-primary btn-sm" onclick="event.stopPropagation(); viewDonation(${d.id})">View</button>
            </div>
        </div>
    `).join('');
}

function renderIncomingRequests(requests) {
    const body = document.getElementById('incomingRequestsBody');
    if (!body) return;

    if (!requests || requests.length === 0) {
        body.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-secondary); padding:30px;">No requests yet.</td></tr>`;
        return;
    }

    body.innerHTML = requests.map(r => {
        let action = '';
        if (r.status === 'pending') {
            action = `
                <button class="btn-icon" title="Accept" onclick="respondToRequest(${r.id}, 'accept')"><i class="fas fa-check" style="color:#22C55E;"></i></button>
                <button class="btn-icon" title="Reject" onclick="respondToRequest(${r.id}, 'reject')"><i class="fas fa-times" style="color:#EF4444;"></i></button>`;
        } else if (r.status === 'accepted') {
            action = `<span style="color:var(--text-secondary); font-size:13px;">Awaiting delivery</span>`;
        } else if (r.status === 'completed') {
            action = (r.already_reviewed == 1)
                ? `<span style="color:var(--text-secondary); font-size:13px;"><i class="fas fa-check"></i> Reviewed</span>`
                : `<button class="btn-secondary btn-sm" onclick="openDonorReviewModal(${r.id}, '${escapeHtml(r.recipient_name).replace(/'/g, "\\'")}')">Leave Review</button>`;
        } else {
            action = `<span style="color:var(--text-secondary); font-size:13px;">—</span>`;
        }

        return `
        <tr>
            <td>${escapeHtml(r.title)}</td>
            <td>${escapeHtml(r.recipient_name)}</td>
            <td>${escapeHtml(r.message || '—')}</td>
            <td><span class="status ${r.status}">${r.status}</span></td>
            <td>${timeAgo(r.created_at)}</td>
            <td>${action}</td>
        </tr>
    `;
    }).join('');
}

async function respondToRequest(requestId, action) {
    const endpoint = `${API_BASE_URL}/requests.php?action=${action}`;
    const result = await apiCall(endpoint, 'POST', { id: requestId });

    if (result.success) {
        showNotification(`Request ${action === 'accept' ? 'accepted' : 'rejected'}`, 'success');
        loadDonorDashboardData();
    } else {
        showNotification(result.message || 'Failed to update request', 'error');
    }
}

let donorReviewRequestId = null;
let donorReviewRating = 0;

function openDonorReviewModal(requestId, recipientName) {
    donorReviewRequestId = requestId;
    donorReviewRating = 0;
    const label = document.getElementById('donorReviewFor');
    const comment = document.getElementById('donorReviewComment');
    const modal = document.getElementById('donorReviewModal');
    if (!modal) return;
    if (label) label.textContent = `How was your experience with ${recipientName}?`;
    if (comment) comment.value = '';
    document.querySelectorAll('#donorStarInput i').forEach(s => s.classList.remove('selected'));
    modal.classList.add('show');
    modal.style.display = 'flex';
}

function closeDonorReviewModal() {
    const modal = document.getElementById('donorReviewModal');
    if (!modal) return;
    modal.classList.remove('show');
    modal.style.display = 'none';
}

async function submitDonorReview() {
    if (!donorReviewRating) {
        showNotification('Please select a star rating', 'error');
        return;
    }

    const endpoint = `${API_BASE_URL}/reviews.php?action=create`;
    const result = await apiCall(endpoint, 'POST', {
        request_id: donorReviewRequestId,
        rating: donorReviewRating,
        comment: (document.getElementById('donorReviewComment')?.value || '').trim() || null
    });

    if (result.success) {
        showNotification('Thanks for your review!', 'success');
        closeDonorReviewModal();
        loadDonorDashboardData();
    } else {
        showNotification(result.message || 'Failed to submit review', 'error');
    }
}

document.addEventListener('click', (event) => {
    const starInput = document.getElementById('donorStarInput');
    const star = event.target.closest('#donorStarInput i');
    if (starInput && star) {
        donorReviewRating = parseInt(star.dataset.value, 10);
        document.querySelectorAll('#donorStarInput i').forEach(s => {
            s.classList.toggle('selected', parseInt(s.dataset.value, 10) <= donorReviewRating);
        });
        return;
    }
    const modal = document.getElementById('donorReviewModal');
    if (modal && event.target === modal) closeDonorReviewModal();
});


document.addEventListener('DOMContentLoaded', async () => {
    const isAuthenticated = await verifyAuthOrRedirect();
    if (isAuthenticated) {
        loadDonorDashboardData();
    }
});
