/* ============================================
   ADMIN DASHBOARD — data & logic (admin role only)
   ============================================ */

async function loadAdminDashboardData() {
    await loadAdminStats();
    await loadAdminUsers();
}

const adminIconMap = {
    total_users: { icon: 'fa-users', color: '#06B6D4', label: 'Total Users' },
    total_donations: { icon: 'fa-box-open', color: '#D946EF', label: 'Total Donations' },
    active_donations: { icon: 'fa-circle-check', color: '#22C55E', label: 'Active Donations' },
    total_requests: { icon: 'fa-clipboard-list', color: '#FBBF24', label: 'Total Requests' },
    pending_requests: { icon: 'fa-hourglass-half', color: '#FBBF24', label: 'Pending Requests' },
    total_deliveries: { icon: 'fa-truck', color: '#A78BFA', label: 'Total Deliveries' },
    completed_deliveries: { icon: 'fa-flag-checkered', color: '#22C55E', label: 'Completed Deliveries' },
    suspended_users: { icon: 'fa-user-slash', color: '#EF4444', label: 'Suspended Users' }
};

async function loadAdminStats() {
    const endpoint = `${API_BASE_URL}/admin.php?action=stats`;
    const result = await apiCall(endpoint);
    const grid = document.getElementById('adminStatsGrid');
    if (!grid) return;

    if (!result.success) {
        grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;"><p>${result.message || 'Could not load stats.'}</p></div>`;
        return;
    }

    const keys = ['total_users', 'total_donations', 'active_donations', 'total_requests', 'pending_requests', 'total_deliveries', 'completed_deliveries', 'suspended_users'];

    grid.innerHTML = keys.map(key => {
        const meta = adminIconMap[key];
        return `
            <div class="admin-stat-card">
                <div class="icon-box" style="background:${meta.color}22; color:${meta.color};"><i class="fas ${meta.icon}"></i></div>
                <div>
                    <h3>${result.data[key] ?? 0}</h3>
                    <p>${meta.label}</p>
                </div>
            </div>`;
    }).join('');
}

async function loadAdminUsers() {
    const q = document.getElementById('userSearchInput')?.value.trim() || '';
    const role = document.getElementById('userRoleFilter')?.value || '';

    const params = new URLSearchParams({ action: 'users', per_page: '50' });
    if (q) params.set('q', q);
    if (role) params.set('role', role);

    const endpoint = `${API_BASE_URL}/admin.php?${params.toString()}`;
    const result = await apiCall(endpoint);
    const body = document.getElementById('usersTableBody');
    if (!body) return;

    if (!result.success || !result.data.length) {
        body.innerHTML = `<tr><td colspan="7" style="text-align:center; color:var(--text-secondary); padding:30px;">${result.success ? 'No users found.' : (result.message || 'Failed to load users.')}</td></tr>`;
        return;
    }

    body.innerHTML = result.data.map(u => `
        <tr>
            <td>${escapeHtml(u.full_name)}</td>
            <td>${escapeHtml(u.email)}</td>
            <td><span class="role-pill">${u.role}</span></td>
            <td><span class="status-pill ${u.status}">${u.status}</span></td>
            <td>${parseFloat(u.rating || 0).toFixed(1)}</td>
            <td>${formatDate(u.created_at)}</td>
            <td>
                ${u.status === 'suspended'
                    ? `<button class="btn-icon" title="Reactivate" onclick="setUserStatus(${u.id}, 'active')"><i class="fas fa-rotate-left" style="color:#22C55E;"></i></button>`
                    : `<button class="btn-icon" title="Suspend" onclick="setUserStatus(${u.id}, 'suspended')"><i class="fas fa-ban" style="color:#EF4444;"></i></button>`
                }
            </td>
        </tr>
    `).join('');
}

async function setUserStatus(userId, status) {
    const endpoint = `${API_BASE_URL}/admin.php?action=update-user-status`;
    const result = await apiCall(endpoint, 'POST', { id: userId, status });

    if (result.success) {
        showNotification('User status updated', 'success');
        loadAdminUsers();
    } else {
        showNotification(result.message || 'Failed to update user', 'error');
    }
}

async function loadAdminDonations() {
    const endpoint = `${API_BASE_URL}/admin.php?action=donations&per_page=50`;
    const result = await apiCall(endpoint);
    const body = document.getElementById('adminDonationsBody');
    if (!body) return;

    if (!result.success || !result.data.length) {
        body.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-secondary); padding:30px;">${result.success ? 'No donations found.' : (result.message || 'Failed to load donations.')}</td></tr>`;
        return;
    }

    body.innerHTML = result.data.map(d => `
        <tr>
            <td>${escapeHtml(d.title)}</td>
            <td>${escapeHtml(d.donor_name)}</td>
            <td>${escapeHtml(d.quantity)}</td>
            <td>${escapeHtml(d.location)}</td>
            <td><span class="status ${d.status}">${d.status.replace('_', ' ')}</span></td>
            <td>${formatDate(d.created_at)}</td>
        </tr>
    `).join('');
}

async function loadAdminLogs() {
    const endpoint = `${API_BASE_URL}/admin.php?action=logs&limit=50`;
    const result = await apiCall(endpoint);
    const body = document.getElementById('logsTableBody');
    if (!body) return;

    if (!result.success || !result.data.length) {
        body.innerHTML = `<tr><td colspan="4" style="text-align:center; color:var(--text-secondary); padding:30px;">${result.success ? 'No activity yet.' : (result.message || 'Failed to load logs.')}</td></tr>`;
        return;
    }

    body.innerHTML = result.data.map(l => `
        <tr>
            <td>${escapeHtml(l.user_name || 'System')}</td>
            <td>${escapeHtml(l.action)}</td>
            <td>${escapeHtml(l.description || '—')}</td>
            <td>${timeAgo(l.created_at)}</td>
        </tr>
    `).join('');
}

/* ============================================
   HELPERS
   ============================================ */

document.addEventListener('DOMContentLoaded', async () => {
    const isAuthenticated = await verifyAuthOrRedirect();
    if (isAuthenticated) {
        loadAdminDashboardData();
    }
});
