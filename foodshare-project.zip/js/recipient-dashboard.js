/* ============================================
   RECIPIENT / NGO DASHBOARD — data & logic (recipient role only)
   ============================================ */

async function loadRecipientDashboardData() {
    const nearbyEndpoint = `${API_BASE_URL}/donations.php?action=list&status=available&per_page=6`;
    const nearbyResult = await apiCall(nearbyEndpoint);
    if (nearbyResult.success) {
        renderDonationsPreview('nearbyDonations', nearbyResult.data);
    }

    const requestsEndpoint = `${API_BASE_URL}/requests.php?action=list&per_page=50`;
    const requestsResult = await apiCall(requestsEndpoint);
    if (requestsResult.success) {
        renderRequestsPreview('myRequests', requestsResult.data);

        const completed = requestsResult.data.filter(r => r.status === 'completed').length;
        setText('statRequestsMade', requestsResult.data.length);
        setText('statCompleted', completed);
    }
}

function renderDonationsPreview(containerId, donations) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (!donations || donations.length === 0) {
        container.innerHTML = '<p class="no-data" style="color:var(--text-secondary);">No donations available right now.</p>';
        return;
    }

    container.innerHTML = donations.map(d => `
        <div class="donation-card" style="margin-bottom:14px;">
            <div class="card-header" onclick="viewDonation(${d.id})" style="cursor:pointer;">
                <h3>${escapeHtml(d.title)}</h3>
                <span class="status ${d.status}">${d.status.replace('_', ' ')}</span>
            </div>
            <div class="card-body" onclick="viewDonation(${d.id})" style="cursor:pointer;">
                <p><strong>Quantity:</strong> ${escapeHtml(d.quantity)}</p>
                <p><strong>Donor:</strong> ${escapeHtml(d.donor_name)}</p>
            </div>
            <div class="card-footer">
                <span class="time-ago">${d.created_at ? timeAgo(d.created_at) : ''}</span>
                <button class="btn-primary btn-sm" onclick="quickRequestDonation(${d.id}, this)">Request</button>
            </div>
        </div>
    `).join('');
}

async function quickRequestDonation(donationId, buttonEl) {
    if (buttonEl) {
        buttonEl.disabled = true;
        buttonEl.textContent = 'Requesting...';
    }

    const endpoint = `${API_BASE_URL}/requests.php?action=create`;
    const result = await apiCall(endpoint, 'POST', { donation_id: donationId });

    if (result.success) {
        showNotification('Request sent to the donor!', 'success');
        loadRecipientDashboardData();
    } else {
        showNotification(result.message || 'Failed to send request', 'error');
        if (buttonEl) {
            buttonEl.disabled = false;
            buttonEl.textContent = 'Request';
        }
    }
}

function renderRequestsPreview(containerId, requests) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (!requests || requests.length === 0) {
        container.innerHTML = '<p class="no-data" style="color:var(--text-secondary);">You haven\'t made any requests yet.</p>';
        return;
    }

    container.innerHTML = requests.slice(0, 6).map(r => `
        <div class="donation-card" style="margin-bottom:14px; cursor:default;">
            <div class="card-header">
                <h3>${escapeHtml(r.title)}</h3>
                <span class="status ${r.status}">${r.status}</span>
            </div>
            <div class="card-body">
                <p><strong>Donor:</strong> ${escapeHtml(r.donor_name)}</p>
                <p><strong>Location:</strong> ${escapeHtml(r.location)}</p>
            </div>
        </div>
    `).join('');
}

/* ============================================
   VOLUNTEER DASHBOARD
   ============================================ */


document.addEventListener('DOMContentLoaded', async () => {
    const isAuthenticated = await verifyAuthOrRedirect();
    if (isAuthenticated) {
        loadRecipientDashboardData();
    }
});
