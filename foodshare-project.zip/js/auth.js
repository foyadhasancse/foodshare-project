
function openLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'flex';
    }
}

function closeLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) {
        modal.classList.remove('show');
        modal.style.display = 'none';
    }
}

function openSignupModal() {
    const modal = document.getElementById('signupModal');
    if (modal) {
        modal.classList.add('show');
        modal.style.display = 'flex';
    }
}

function closeSignupModal() {
    const modal = document.getElementById('signupModal');
    if (modal) {
        modal.classList.remove('show');
        modal.style.display = 'none';
    }
}

function switchToSignup() {
    closeLoginModal();
    openSignupModal();
}

function switchToLogin() {
    closeSignupModal();
    openLoginModal();
}

async function handleLogin(event) {
    event.preventDefault();

    const form = event.target;
    const email = form.querySelector('input[type="text"]').value;
    const password = form.querySelector('input[type="password"]').value;

    if (!email || !password) {
        showNotification('Please fill in all fields', 'error');
        return;
    }

    const endpoint = `${API_BASE_URL}/auth.php?action=login`;
    const result = await apiCall(endpoint, 'POST', {
        email: email,
        password: password
    });

    if (result.success) {

        sessionStorage.setItem('auth_token', result.data.token);
        sessionStorage.setItem('user_id', result.data.user_id);
        sessionStorage.setItem('user_role', result.data.role);
        sessionStorage.setItem('user_name', result.data.full_name);

        showNotification('Login successful! Redirecting...', 'success');
        closeLoginModal();

        setTimeout(() => {
            const role = result.data.role;
            if (role === 'admin') {
                window.location.href = '/foodshare-project/pages/admin-dashboard.html';
            } else if (role === 'donor') {
                window.location.href = '/foodshare-project/pages/donor-dashboard.html';
            } else if (role === 'recipient') {
                window.location.href = '/foodshare-project/pages/recipient-dashboard.html';
            } else if (role === 'ngo') {
                window.location.href = '/foodshare-project/pages/ngo-dashboard.html';
            } else if (role === 'volunteer') {
                window.location.href = '/foodshare-project/pages/volunteer-dashboard.html';
            } else {
                window.location.href = '/foodshare-project/pages/dashboard.html';
            }
        }, 1500);
    } else {
        showNotification(result.message, 'error');
    }
}

async function handleSignup(event) {
    event.preventDefault();

    const form = event.target;
    const fullName = form.querySelector('input[placeholder="Enter your full name"]').value;
    const email = form.querySelector('input[type="email"]').value;
    const phone = form.querySelector('input[type="tel"]').value;
    const accountType = form.querySelector('select').value;
    const password = form.querySelectorAll('input[type="password"]')[0].value;
    const confirmPassword = form.querySelectorAll('input[type="password"]')[1].value;

    if (!fullName || !email || !phone || !accountType || !password) {
        showNotification('Please fill in all fields', 'error');
        return;
    }

    if (!validateEmail(email)) {
        showNotification('Invalid email format', 'error');
        return;
    }

    if (!validatePhone(phone)) {
        showNotification('Invalid phone format', 'error');
        return;
    }

    if (password.length < 6) {
        showNotification('Password must be at least 6 characters', 'error');
        return;
    }

    if (password !== confirmPassword) {
        showNotification('Passwords do not match', 'error');
        return;
    }

    const endpoint = `${API_BASE_URL}/auth.php?action=register`;
    const result = await apiCall(endpoint, 'POST', {
        full_name: fullName,
        email: email,
        phone: phone,
        account_type: accountType,
        password: password
    });

    if (result.success) {
        sessionStorage.setItem('auth_token', result.data.token);
        sessionStorage.setItem('user_id', result.data.user_id);
        sessionStorage.setItem('user_role', result.data.role);
        sessionStorage.setItem('user_name', result.data.full_name);

        showNotification('Account created successfully! Redirecting...', 'success');
        closeSignupModal();

        setTimeout(() => {
            const role = result.data.role;
            if (role === 'admin') {
                window.location.href = '/foodshare-project/pages/admin-dashboard.html';
            } else if (role === 'donor') {
                window.location.href = '/foodshare-project/pages/donor-dashboard.html';
            } else if (role === 'recipient') {
                window.location.href = '/foodshare-project/pages/recipient-dashboard.html';
            } else if (role === 'ngo') {
                window.location.href = '/foodshare-project/pages/ngo-dashboard.html';
            } else if (role === 'volunteer') {
                window.location.href = '/foodshare-project/pages/volunteer-dashboard.html';
            }
        }, 1500);
    } else {
        showNotification(result.message, 'error');
    }
}

async function handleLogout() {
    const endpoint = `${API_BASE_URL}/auth.php?action=logout`;
    await apiCall(endpoint, 'POST');

    sessionStorage.removeItem('auth_token');
    sessionStorage.removeItem('user_id');
    sessionStorage.removeItem('user_role');
    sessionStorage.removeItem('user_name');

    showNotification('Logged out successfully', 'success');

    setTimeout(() => {
        window.location.href = '/foodshare-project/';
    }, 1000);
}

function loadUserSession() {
    const token = sessionStorage.getItem('auth_token');
    const userName = sessionStorage.getItem('user_name');

    if (token && userName) {
        const userNameElement = document.querySelector('.user-name');
        if (userNameElement) {
            userNameElement.textContent = userName;
        }
    }
}

document.addEventListener('click', (event) => {
    const loginModal = document.getElementById('loginModal');
    const signupModal = document.getElementById('signupModal');

    if (event.target === loginModal) {
        closeLoginModal();
    }

    if (event.target === signupModal) {
        closeSignupModal();
    }
});

function handleContactSubmit(event) {
    event.preventDefault();
    showNotification('Thank you! We will get back to you soon.', 'success');
    event.target.reset();
}
