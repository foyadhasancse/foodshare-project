

const PROJECT_BASE = window.location.pathname.includes('/pages/')
    ? window.location.pathname.split('/pages/')[0]
    : window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/'));
const API_BASE_URL = window.location.origin + PROJECT_BASE + '/api';

async function apiCall(endpoint, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            }
        };

        const token = sessionStorage.getItem('auth_token');
        if (token) {
            options.headers['Authorization'] = `Bearer ${token}`;
        }

        if (data && (method === 'POST' || method === 'PUT')) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(endpoint, options);
        const result = await response.json();

        const isLoginAttempt = endpoint.includes('action=login');
        if (!response.ok && response.status === 401 && !isLoginAttempt) {
            handleLogout();
        }

        return result;
    } catch (error) {
        console.error('API Error:', error);
        return {
            success: false,
            message: 'Network error occurred'
        };
    }
}

function showNotification(message, type = 'info') {
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-circle-exclamation',
        info: 'fa-circle-info'
    };
    const icon = icons[type] || icons.info;

    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${icon}"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function scrollToSection(id) {
    const element = document.getElementById(id);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function timeAgo(dateString) {
    const date = new Date(dateString);
    const seconds = Math.floor((new Date() - date) / 1000);

    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + ' years ago';

    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + ' months ago';

    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + ' days ago';

    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + ' hours ago';

    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + ' minutes ago';

    return Math.floor(seconds) + ' seconds ago';
}

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[+]?[(]?[0-9]{3}[)]?[-\s]?[0-9]{3}[-\s]?[0-9]{4,6}$/;
    return re.test(phone);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

async function loadDonations(page = 1) {
    const endpoint = `${API_BASE_URL}/donations.php?action=list&page=${page}`;
    const result = await apiCall(endpoint);

    if (result.success) {
        displayDonations(result.data);
    } else {
        showNotification(result.message, 'error');
    }
}

function displayDonations(donations) {
    const container = document.getElementById('donationsList') || document.getElementById('nearbyDonations');
    if (!container) return;

    if (donations.length === 0) {
        container.innerHTML = '<p class="no-data">No donations available</p>';
        return;
    }

    container.innerHTML = donations.map(donation => `
        <div class="donation-card" onclick="viewDonation(${donation.id})">
            <div class="card-header">
                <h3>${donation.title}</h3>
                <span class="status ${donation.status}">${donation.status}</span>
            </div>
            <div class="card-body">
                <p><strong>Quantity:</strong> ${donation.quantity}</p>
                <p><strong>Location:</strong> ${donation.location}</p>
                <p><strong>Donor:</strong> ${donation.donor_name}</p>
                <p class="description">${donation.description}</p>
            </div>
            <div class="card-footer">
                <span class="time-ago">${timeAgo(donation.created_at)}</span>
                <button class="btn-primary btn-sm">View Details</button>
            </div>
        </div>
    `).join('');
}

/**
 * View donation details
 */
function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function viewDonation(id) {
    const role = sessionStorage.getItem('user_role');
    let page;
    if (role === 'recipient') {
        page = 'recipient-donation-details.html';
    } else if (role === 'ngo') {
        page = 'ngo-donation-details.html';
    } else {
        page = 'donation-details.html';
    }
    window.location.href = `../pages/${page}?id=${id}`;
}

/**
 * Hamburger menu toggle
 */
function toggleHamburger() {
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('navLinks');

    if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });
    }
}

function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
}

function renderStars(rating) {
    const r = Math.round(parseFloat(rating) || 0);
    let html = '';
    for (let i = 1; i <= 5; i++) {
        html += `<i class="fas fa-star" style="color:${i <= r ? '#FBBF24' : 'rgba(255,255,255,0.15)'}"></i>`;
    }
    return html;
}

/**
 * Utility: Get initials from a full name for avatar circles
 */
function getInitials(name) {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    const initials = parts.length > 1 ? parts[0][0] + parts[parts.length - 1][0] : parts[0][0];
    return initials.toUpperCase();
}

/**
 * Initialize the authenticated app navbar (avatar initials, active link, unread badge).
 * Safe to call on any page -- no-ops if the elements aren't present.
 */
async function initAppNav() {
    const token = sessionStorage.getItem('auth_token');
    if (!token) return;

    const userName = sessionStorage.getItem('user_name');
    const navAvatar = document.getElementById('navAvatar');
    if (navAvatar && userName) {
        navAvatar.textContent = getInitials(userName);
    }

    const currentPage = window.location.pathname.split('/').pop();
    document.querySelectorAll('.app-nav-links a').forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });

    const badge = document.getElementById('notifBadge');
    if (badge) {
        const endpoint = `${API_BASE_URL}/notifications.php?action=unread-count`;
        const result = await apiCall(endpoint);
        if (result.success && result.data.count > 0) {
            badge.textContent = result.data.count > 99 ? '99+' : result.data.count;
            badge.style.display = 'flex';
        }
    }
}

async function verifyAuthOrRedirect() {
    const token = sessionStorage.getItem('auth_token');
    if (!token) {
        window.location.href = '../index.html';
        return false;
    }

    const result = await apiCall(`${API_BASE_URL}/auth.php?action=me`);

    if (!result.success) {
        sessionStorage.removeItem('auth_token');
        sessionStorage.removeItem('user_id');
        sessionStorage.removeItem('user_role');
        sessionStorage.removeItem('user_name');
        window.location.href = '../index.html';
        return false;
    }

    return true;
}

/**
 * On the public homepage (index.html), swap the guest Login/Join Us buttons
 * for a Dashboard/Logout state when the user already has a valid session.
 * No-ops on any page that doesn't have these nav elements.
 */
function updateHomeNavAuth() {
    const guestNav = document.getElementById('navAuthGuest');
    const userNav = document.getElementById('navAuthUser');
    if (!guestNav || !userNav) return;

    const token = sessionStorage.getItem('auth_token');
    const role = sessionStorage.getItem('user_role');

    if (!token) {
        guestNav.style.display = '';
        userNav.style.display = 'none';
        return;
    }

    const dashboardByRole = {
        admin: 'pages/admin-dashboard.html',
        donor: 'pages/donor-dashboard.html',
        recipient: 'pages/recipient-dashboard.html',
        ngo: 'pages/ngo-dashboard.html',
        volunteer: 'pages/volunteer-dashboard.html'
    };

    const dashboardLink = document.getElementById('navDashboardLink');
    if (dashboardLink) {
        dashboardLink.href = dashboardByRole[role] || dashboardByRole.donor;
    }

    guestNav.style.display = 'none';
    userNav.style.display = '';
}

document.addEventListener('DOMContentLoaded', () => {
    toggleHamburger();
    loadUserSession();
    initAppNav();
    updateHomeNavAuth();
});

/**
 * If the browser restores this page from the back/forward cache (bfcache) --
 * e.g. the user hits the back button after logging out -- force a fresh
 * reload instead of showing the stale cached snapshot. This makes the
 * auth check (verifyAuthOrRedirect) re-run immediately and consistently,
 * instead of flashing old dashboard content for a moment.
 */
window.addEventListener('pageshow', (event) => {
    if (event.persisted) {
        window.location.reload();
    }
});