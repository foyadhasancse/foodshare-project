/* ============================================
   VOLUNTEER DASHBOARD — data & logic (volunteer role only)
   ============================================ */

async function loadVolunteerDashboardData() {
    const jobsEndpoint = `${API_BASE_URL}/deliveries.php?action=available`;
    const jobsResult = await apiCall(jobsEndpoint);
    if (jobsResult.success) {
        renderJobsList('availableJobs', jobsResult.data, true);
    } else {

        const el = document.getElementById('availableJobs');
        if (el) el.innerHTML = `<p class="no-data" style="color:#EF4444;">Could not load jobs: ${escapeHtml(jobsResult.message || 'unknown error')}</p>`;
    }

    const activeEndpoint = `${API_BASE_URL}/deliveries.php?action=list&status=in_progress&per_page=50`;
    const activeResult = await apiCall(activeEndpoint);
    if (activeResult.success) {
        renderJobsList('activeDeliveries', activeResult.data, false);
        setText('statActiveJobs', activeResult.data.length);
    } else {
        const el = document.getElementById('activeDeliveries');
        if (el) el.innerHTML = `<p class="no-data" style="color:#EF4444;">Could not load deliveries: ${escapeHtml(activeResult.message || 'unknown error')}</p>`;
    }

    const profileResult = await apiCall(`${API_BASE_URL}/auth.php?action=me`);
    if (profileResult.success) {
        setText('statAvgRating', parseFloat(profileResult.data.rating || 0).toFixed(1));
    }

    const completedEndpoint = `${API_BASE_URL}/deliveries.php?action=list&status=completed&per_page=100`;
    const completedResult = await apiCall(completedEndpoint);
    if (completedResult.success) {
        setText('statDeliveriesCompleted', completedResult.data.length);
    }
}

function renderJobsList(containerId, deliveries, showAccept) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (!deliveries || deliveries.length === 0) {
        container.innerHTML = `<p class="no-data" style="color:var(--text-secondary);">${showAccept ? 'No delivery jobs available right now.' : 'No active deliveries.'}</p>`;
        return;
    }

    container.innerHTML = deliveries.map(d => {
        let footer = '';
        if (showAccept) {
            footer = `<div class="card-footer"><span></span><button class="btn-primary btn-sm" onclick="acceptDeliveryJob(${d.id})">Accept Job</button></div>`;
        } else if (!d.pickup_time) {
            footer = `<div class="card-footer"><span>Assigned to you</span><button class="btn-primary btn-sm" onclick="markPickedUp(${d.id})">Mark Picked Up</button></div>`;
        } else {
            footer = `<div class="card-footer"><span style="color:var(--text-secondary); font-size:13px;">Picked up — waiting for recipient to confirm delivery</span></div>`;
        }

        return `
        <div class="donation-card" style="margin-bottom:14px; cursor:default;">
            <div class="card-header">
                <h3>${escapeHtml(d.donation_title || 'Delivery #' + d.id)}</h3>
                <span class="status ${d.status}">${d.pickup_time ? 'picked up' : d.status.replace('_', ' ')}</span>
            </div>
            <div class="card-body">
                <p><strong>Pickup:</strong> ${escapeHtml(d.pickup_location)}</p>
                <p><strong>Deliver to:</strong> ${escapeHtml(d.delivery_location)}</p>
                ${d.donor_name ? `<p><strong>Donor:</strong> ${escapeHtml(d.donor_name)}</p>` : ''}
            </div>
            ${footer}
        </div>`;
    }).join('');
}

async function acceptDeliveryJob(deliveryId) {
    const endpoint = `${API_BASE_URL}/deliveries.php?action=accept`;
    const result = await apiCall(endpoint, 'POST', { id: deliveryId });

    if (result.success) {
        showNotification('Delivery job accepted — head to the donor to pick it up', 'success');
        loadVolunteerDashboardData();
    } else {
        showNotification(result.message || 'Failed to accept job', 'error');
    }
}

async function markPickedUp(deliveryId) {
    if (!confirm('Confirm you have collected the food from the donor?')) return;

    const endpoint = `${API_BASE_URL}/deliveries.php?action=pickup`;
    const result = await apiCall(endpoint, 'POST', { id: deliveryId });

    if (result.success) {
        showNotification('Marked as picked up — deliver it to the recipient', 'success');
        loadVolunteerDashboardData();
    } else {
        showNotification(result.message || 'Failed to update delivery', 'error');
    }
}


document.addEventListener('DOMContentLoaded', async () => {
    const isAuthenticated = await verifyAuthOrRedirect();
    if (isAuthenticated) {
        loadVolunteerDashboardData();
    }
});
