<?php
require_once __DIR__ . '/../config/constants.php';

function sendWelcomeEmail($email, $fullName) {
    $subject = 'Welcome to FoodShare';
    $body = "<h2>Welcome to FoodShare, $fullName!</h2>
             <p>Thank you for joining our community.</p>
             <p>Best regards, FoodShare Team</p>";
    return sendEmail($email, $subject, $body);
}

function sendDonationRequestEmail($donorEmail, $donorName, $recipientName, $donationTitle) {
    $subject = 'New Request for Your Donation';
    $body = "<h2>Hello $donorName,</h2>
             <p>$recipientName is interested in your donation: <strong>$donationTitle</strong></p>
             <p>Best regards, FoodShare Team</p>";
    return sendEmail($donorEmail, $subject, $body);
}

?>