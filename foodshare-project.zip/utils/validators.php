<?php

function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function isValidPhone($phone) {
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    return strlen($phone) >= 10 && strlen($phone) <= 15;
}

function isValidURL($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

function isValidPassword($password) {
    return strlen($password) >= 6 && strlen($password) <= 128;
}

function isValidUsername($username) {
    return preg_match('/^[a-zA-Z0-9_-]{3,20}$/', $username);
}

function isValidFileExtension($filename) {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($extension, ALLOWED_EXTENSIONS);
}

function isValidFileSize($fileSize) {
    return $fileSize <= MAX_UPLOAD_SIZE;
}

function isValidFileUpload($file) {
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return false;
    }

    if (!isValidFileSize($file['size'])) {
        return false;
    }

    if (!isValidFileExtension($file['name'])) {
        return false;
    }

    return true;
}

function isValidCoordinates($latitude, $longitude) {
    $lat = floatval($latitude);
    $lng = floatval($longitude);

    return $lat >= -90 && $lat <= 90 && $lng >= -180 && $lng <= 180;
}

function isValidDateFormat($date, $format = 'Y-m-d') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

?>