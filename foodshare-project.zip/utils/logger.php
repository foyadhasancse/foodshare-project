<?php

if (!function_exists('logActivity')) {
    function logActivity($userId, $action, $description = null) {
        global $conn;

        if (!isset($conn)) return false;

        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        $stmt = $conn->prepare(
            "INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent)
             VALUES (?, ?, ?, ?, ?)"
        );

        if (!$stmt) return false;

        $stmt->bind_param("issss", $userId, $action, $description, $ipAddress, $userAgent);
        $result = $stmt->execute();
        $stmt->close();

        return $result;
    }
}

function getUserActivityLogs($userId, $limit = 50) {
    global $conn;

    if (!isset($conn)) return [];

    $stmt = $conn->prepare(
        "SELECT id, action, description, created_at
         FROM activity_logs
         WHERE user_id = ?
         ORDER BY created_at DESC
         LIMIT ?"
    );

    if (!$stmt) return [];

    $stmt->bind_param("ii", $userId, $limit);
    $stmt->execute();
    $result = $stmt->get_result();

    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    $stmt->close();

    return $logs;
}
?>
