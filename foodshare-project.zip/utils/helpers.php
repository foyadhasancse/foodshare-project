<?php

require_once __DIR__ . '/../config/constants.php';

function generateJWT($data, $expiresIn = 86400) {
    $header = json_encode(['alg' => 'HS256', 'typ' => 'JWT']);
    $payload = json_encode(array_merge($data, [
        'exp' => time() + $expiresIn,
        'iat' => time()
    ]));

    $base64Header = rtrim(strtr(base64_encode($header), '+/', '-_'), '=');
    $base64Payload = rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');

    $signature = hash_hmac(
        'sha256',
        $base64Header . '.' . $base64Payload,
        'your-secret-key-here',
        true
    );
    $base64Signature = rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');

    return $base64Header . '.' . $base64Payload . '.' . $base64Signature;
}

function verifyJWT($token) {
    $parts = explode('.', $token);

    if (count($parts) !== 3) {
        return false;
    }

    $base64Header = $parts[0];
    $base64Payload = $parts[1];
    $signature = $parts[2];

    $expectedSignature = rtrim(strtr(base64_encode(hash_hmac(
        'sha256',
        $base64Header . '.' . $base64Payload,
        'your-secret-key-here',
        true
    )), '+/', '-_'), '=');

    if ($signature !== $expectedSignature) {
        return false;
    }

    $payload = json_decode(base64_decode(strtr($base64Payload, '-_', '+/')), true);

    if ($payload['exp'] < time()) {
        return false;
    }

    return $payload;
}

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function sanitizeEmail($email) {
    return filter_var($email, FILTER_SANITIZE_EMAIL);
}

function logActivity($userId, $action, $description = null) {
    global $conn;

    if (!isset($conn)) return false;

    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    $stmt = $conn->prepare(
        "INSERT INTO activity_logs (user_id, action, description, ip_address, user_agent)
         VALUES (?, ?, ?, ?, ?)"
    );

    if (!$stmt) return false;

    $stmt->bind_param("issss", $userId, $action, $description, $ipAddress, $userAgent);
    $result = $stmt->execute();
    $stmt->close();

    return $result;
}

function sendEmail($to, $subject, $body, $headers = null) {
    $defaultHeaders = "From: " . FROM_NAME . " <" . FROM_EMAIL . ">\r\n";
    $defaultHeaders .= "Content-Type: text/html; charset=UTF-8\r\n";

    $allHeaders = $defaultHeaders . ($headers ?? '');

    return mail($to, $subject, $body, $allHeaders);
}

function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));

    return round($bytes, 2) . ' ' . $units[$pow];
}

function getUserById($userId) {
    global $conn;

    if (!isset($conn)) return null;

    $stmt = $conn->prepare(
        "SELECT id, full_name, email, phone, role, rating, profile_picture FROM users WHERE id = ?"
    );

    if (!$stmt) return null;

    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    return $user;
}

function getDonationsCount() {
    global $conn;

    if (!isset($conn)) return 0;

    $result = $conn->query("SELECT COUNT(*) as count FROM donations WHERE status = 'available'");
    $row = $result->fetch_assoc();

    return $row['count'];
}

function getRequestsCount($userId) {
    global $conn;

    if (!isset($conn)) return 0;

    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM requests WHERE recipient_id = ? AND status = 'pending'");

    if (!$stmt) return 0;

    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    return $row['count'];
}

function createNotification($userId, $title, $message, $type = null, $referenceId = null, $referenceType = null) {
    global $conn;

    if (!isset($conn) || !$userId) return false;

    $stmt = $conn->prepare(
        "INSERT INTO notifications (user_id, title, message, type, reference_id, reference_type)
         VALUES (?, ?, ?, ?, ?, ?)"
    );

    if (!$stmt) return false;

    $stmt->bind_param("isssis", $userId, $title, $message, $type, $referenceId, $referenceType);
    $result = $stmt->execute();
    $stmt->close();

    return $result;
}

?>