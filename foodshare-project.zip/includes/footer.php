<?php

?>
    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>FoodShare</h4>
                <p>Reducing food waste, feeding communities, building hope.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="<?php echo APP_URL; ?>">Home</a></li>
                    <li><a href="<?php echo APP_URL; ?>/pages/about.html">About</a></li>
                    <li><a href="<?php echo APP_URL; ?>/pages/faq.html">FAQ</a></li>
                    <li><a href="<?php echo APP_URL; ?>/pages/contact.html">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Follow Us</h4>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 FoodShare. All rights reserved. | Design Project I - CSE2200</p>
        </div>
    </footer>

    <script src="<?php echo APP_URL; ?>/js/main.js"></script>
    <script src="<?php echo APP_URL; ?>/js/auth.js"></script>
</body>
</html>
