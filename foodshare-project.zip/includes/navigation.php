<?php

$currentPage = basename($_SERVER['REQUEST_URI'], '.php');
?>

<nav class="navbar">
    <div class="nav-container">
        <div class="logo">
            <i class="fas fa-leaf"></i>
            <span>FOODSHARE</span>
        </div>
        <ul class="nav-links" id="navLinks">
            <li><a href="<?php echo APP_URL; ?>" <?php echo $currentPage == 'index' ? 'class="active"' : ''; ?>>Home</a></li>
            <li><a href="<?php echo APP_URL; ?>/pages/about.html" <?php echo strpos($currentPage, 'about') !== false ? 'class="active"' : ''; ?>>About</a></li>
            <li><a href="<?php echo APP_URL; ?>/pages/faq.html" <?php echo strpos($currentPage, 'faq') !== false ? 'class="active"' : ''; ?>>FAQ</a></li>
            <li><a href="<?php echo APP_URL; ?>/pages/contact.html" <?php echo strpos($currentPage, 'contact') !== false ? 'class="active"' : ''; ?>>Contact</a></li>
        </ul>
        <div class="nav-auth">
            <?php if (isset($_SESSION['user'])): ?>
                <span class="user-name"><?php echo htmlspecialchars($_SESSION['user']['full_name']); ?></span>
                <div class="dropdown">
                    <button class="btn-profile">Profile</button>
                    <div class="dropdown-content">
                        <a href="<?php echo APP_URL; ?>/pages/profile.html">My Profile</a>
                        <a href="<?php echo APP_URL; ?>/pages/notifications.html">Notifications</a>
                        <a href="#" onclick="handleLogout()">Logout</a>
                    </div>
                </div>
            <?php else: ?>
                <button class="btn-login" onclick="openLoginModal()">Login</button>
                <button class="btn-signup" onclick="openSignupModal()">Join Us</button>
            <?php endif; ?>
        </div>
        <div class="hamburger" id="hamburger">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</nav>
