<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - FoodShare' : 'FoodShare'; ?></title>
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-leaf"></i>
                <span>FOODSHARE</span>
            </div>
            <ul class="nav-links">
                <li><a href="<?php echo APP_URL; ?>">Home</a></li>
                <li><a href="<?php echo APP_URL; ?>/pages/about.html">About</a></li>
                <li><a href="<?php echo APP_URL; ?>/pages/faq.html">FAQ</a></li>
                <li><a href="<?php echo APP_URL; ?>/pages/contact.html">Contact</a></li>
            </ul>
            <div class="nav-auth">
                <?php if (isset($_SESSION['user'])): ?>
                    <span class="user-name"><?php echo $_SESSION['user']['full_name']; ?></span>
                    <button class="btn-logout" onclick="handleLogout()">Logout</button>
                <?php else: ?>
                    <button class="btn-login" onclick="openLoginModal()">Login</button>
                    <button class="btn-signup" onclick="openSignupModal()">Join Us</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</body>
</html>
