<?php

require_once __DIR__ . '/../utils/helpers.php';

function verifyToken() {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authHeader = $headers['Authorization']
        ?? $headers['authorization']
        ?? $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? '';

    if (empty($authHeader)) {
        sendError('Authorization header missing', 401);
    }

    if (!preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        sendError('Invalid authorization header format', 401);
    }

    $token = $matches[1];
    $payload = verifyJWT($token);

    if (!$payload) {
        sendError('Invalid or expired token', 401);
    }

    $_SESSION['user_id'] = $payload['id'];
    $_SESSION['user_email'] = $payload['email'];
    $_SESSION['user_role'] = $payload['role'];

    return true;
}

function requireRole($role) {
    $userRole = $_SESSION['user_role'] ?? null;

    if ($userRole !== $role) {
        sendError('Insufficient permissions', 403);
    }

    return true;
}

function requireAuth() {
    if (empty($_SESSION['user_id'])) {
        sendError('Authentication required', 401);
    }

    return true;
}

?>