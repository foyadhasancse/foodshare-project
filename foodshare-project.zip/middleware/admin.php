<?php

function requireAdmin() {
    return requireRole(ROLE_ADMIN);
}

?>
